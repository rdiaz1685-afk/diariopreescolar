import { useState, useEffect } from 'react'

export interface Student {
  id: string
  name: string
  lastName: string
  dateOfBirth: Date
  gender: string
  emergencyContact: string
  emergencyPhone: string
  parentEmail: string
  parentPhone: string
  medicalNotes: string | null
  createdAt: Date
  updatedAt: Date
}

export function useStudents() {
  const [students, setStudents] = useState<Student[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    fetchStudents()
  }, [])

  async function fetchStudents() {
    try {
      setLoading(true)
      const response = await fetch('/api/students')
      if (!response.ok) throw new Error('Error fetching students')
      const data = await response.json()
      setStudents(data)
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Unknown error')
    } finally {
      setLoading(false)
    }
  }

  return { students, loading, error, refetch: fetchStudents }
}
