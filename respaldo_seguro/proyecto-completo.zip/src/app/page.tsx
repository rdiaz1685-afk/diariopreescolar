'use client'

import { useState, useEffect } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import { Checkbox } from '@/components/ui/checkbox'
import { Badge } from '@/components/ui/badge'
import { Switch } from '@/components/ui/switch'
import { Avatar, AvatarFallback } from '@/components/ui/avatar'
import { ScrollArea } from '@/components/ui/scroll-area'
import { useToast } from '@/hooks/use-toast'
import { useStudents, Student } from '@/hooks/use-students'
import {
  Baby,
  Mail,
  MessageSquare,
  History,
  CheckCircle2,
  Utensils,
  BedDouble,
  Pill,
  Award,
  Smile,
  Send,
  Search,
  Bell,
  Clock,
  Download
} from 'lucide-react'

export default function DailyReports() {
  const { students, loading: studentsLoading } = useStudents()
  const { toast } = useToast()

  const [selectedStudents, setSelectedStudents] = useState<string[]>([])
  const [activeTab, setActiveTab] = useState('daily')
  const [searchQuery, setSearchQuery] = useState('')
  const [selectedMood, setSelectedMood] = useState<string>('')
  const [selectedLunch, setSelectedLunch] = useState<string>('')
  const [individualAchievements, setIndividualAchievements] = useState<Record<string, string>>({})
  const [generalNotes, setGeneralNotes] = useState('')

  // Calcular edad del estudiante
  const calculateAge = (dateOfBirth: Date) => {
    const today = new Date()
    const birth = new Date(dateOfBirth)
    let age = today.getFullYear() - birth.getFullYear()
    const monthDiff = today.getMonth() - birth.getMonth()
    if (monthDiff < 0 || (monthDiff === 0 && today.getDate() < birth.getDate())) {
      age--
    }
    return age
  }

  // Generar iniciales
  const getInitials = (name: string, lastName: string) => {
    return `${name.charAt(0)}${lastName.charAt(0)}`.toUpperCase()
  }

  // Filtros de búsqueda
  const filteredStudents = students.filter(student =>
    `${student.name} ${student.lastName}`.toLowerCase().includes(searchQuery.toLowerCase())
  )

  // Seleccionar/deseleccionar todos
  const toggleSelectAll = () => {
    if (selectedStudents.length === filteredStudents.length) {
      setSelectedStudents([])
    } else {
      setSelectedStudents(filteredStudents.map(s => s.id))
    }
  }

  // Toggle selección individual
  const toggleStudent = (id: string) => {
    setSelectedStudents(prev =>
      prev.includes(id) ? prev.filter(s => s !== id) : [...prev, id]
    )
  }

  // Aplicar acción a estudiantes seleccionados
  const applyToSelected = async (field: string, value: any) => {
    if (selectedStudents.length === 0) {
      toast({
        title: 'Error',
        description: 'Por favor selecciona al menos un estudiante',
        variant: 'destructive'
      })
      return
    }

    try {
      // Aquí guardaríamos en la base de datos
      toast({
        title: 'Aplicado',
        description: `${field} aplicado a ${selectedStudents.length} estudiantes`
      })
    } catch (error) {
      toast({
        title: 'Error',
        description: 'Error al aplicar cambios',
        variant: 'destructive'
      })
    }
  }

  return (
    <div className="min-h-screen bg-background p-4 md:p-6 lg:p-8">
      <div className="max-w-7xl mx-auto space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-4xl font-bold bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent neon-text">
              Reportes Diarios
            </h1>
            <p className="text-muted-foreground mt-1">
              Sistema de reportes para preescolar con IA
            </p>
          </div>
          <div className="flex items-center gap-2">
            <div className="flex items-center gap-2 text-sm text-muted-foreground">
              <Clock className="w-4 h-4" />
              {new Date().toLocaleDateString('es-ES', {
                weekday: 'long',
                year: 'numeric',
                month: 'long',
                day: 'numeric'
              })}
            </div>
            <Button variant="outline" size="icon">
              <Bell className="w-4 h-4" />
            </Button>
            <Avatar>
              <AvatarFallback className="bg-primary text-primary-foreground">
                MP
              </AvatarFallback>
            </Avatar>
          </div>
        </div>

        {/* Tabs principales */}
        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid w-full grid-cols-3 lg:w-[600px]">
            <TabsTrigger value="daily" className="gap-2">
              <Baby className="w-4 h-4" />
              Captura Diaria
            </TabsTrigger>
            <TabsTrigger value="send" className="gap-2">
              <Send className="w-4 h-4" />
              Enviar Reportes
            </TabsTrigger>
            <TabsTrigger value="history" className="gap-2">
              <History className="w-4 h-4" />
              Historial
            </TabsTrigger>
          </TabsList>

          {/* Tab 1: Captura Diaria */}
          <TabsContent value="daily" className="space-y-6">
            {/* Buscador y selección */}
            <Card className="card-hover neon-border">
              <CardHeader>
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-4 flex-1">
                    <div className="relative flex-1 max-w-md">
                      <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground w-4 h-4" />
                      <Input
                        placeholder="Buscar estudiante..."
                        value={searchQuery}
                        onChange={(e) => setSearchQuery(e.target.value)}
                        className="pl-10"
                      />
                    </div>
                    <div className="flex items-center gap-2 text-sm">
                      <Checkbox
                        id="selectAll"
                        checked={selectedStudents.length === filteredStudents.length && filteredStudents.length > 0}
                        onCheckedChange={toggleSelectAll}
                      />
                      <Label htmlFor="selectAll">
                        Seleccionar todos ({filteredStudents.length})
                      </Label>
                    </div>
                  </div>
                  <Badge variant={selectedStudents.length > 0 ? "default" : "secondary"}>
                    {selectedStudents.length} seleccionados
                  </Badge>
                </div>
              </CardHeader>
            </Card>

            <div className="grid lg:grid-cols-2 gap-6">
              {/* Lista de estudiantes */}
              <Card className="card-hover">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Baby className="w-5 h-5 text-primary" />
                    Estudiantes ({students.length})
                  </CardTitle>
                  <CardDescription>
                    Selecciona los estudiantes para aplicar acciones
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  {studentsLoading ? (
                    <div className="flex items-center justify-center h-[600px]">
                      <p className="text-muted-foreground">Cargando estudiantes...</p>
                    </div>
                  ) : (
                    <ScrollArea className="h-[600px] pr-4">
                      <div className="space-y-3">
                        {filteredStudents.map((student) => (
                          <Card
                            key={student.id}
                            className={`cursor-pointer transition-all ${
                              selectedStudents.includes(student.id)
                                ? 'border-primary bg-primary/5 neon-border'
                                : 'hover:border-primary/50'
                            }`}
                            onClick={() => toggleStudent(student.id)}
                          >
                            <CardContent className="p-4">
                              <div className="flex items-center gap-4">
                                <Checkbox
                                  checked={selectedStudents.includes(student.id)}
                                  onCheckedChange={() => toggleStudent(student.id)}
                                  className="pointer-events-none"
                                />
                                <Avatar>
                                  <AvatarFallback className="bg-accent text-accent-foreground">
                                    {getInitials(student.name, student.lastName)}
                                  </AvatarFallback>
                                </Avatar>
                                <div className="flex-1">
                                  <h3 className="font-semibold">
                                    {student.name} {student.lastName}
                                  </h3>
                                  <p className="text-sm text-muted-foreground">
                                    {calculateAge(student.dateOfBirth)} años
                                  </p>
                                </div>
                                {individualAchievements[student.id] && (
                                  <Badge variant="secondary">
                                    <Award className="w-3 h-3 mr-1" />
                                    Logro
                                  </Badge>
                                )}
                              </div>
                            </CardContent>
                          </Card>
                        ))}
                      </div>
                    </ScrollArea>
                  )}
                </CardContent>
              </Card>

              {/* Panel de acciones */}
              <div className="space-y-6">
                {/* Estado de ánimo */}
                <Card className="card-hover">
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Smile className="w-5 h-5 text-accent" />
                      Estado de Ánimo
                      {selectedStudents.length > 0 && (
                        <Badge variant="secondary">({selectedStudents.length})</Badge>
                      )}
                    </CardTitle>
                    <CardDescription>
                      ¿Cómo estuvo de ánimo durante el día?
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                      {[
                        { mood: 'happy', emoji: '😊', label: 'Alegre', color: 'green' },
                        { mood: 'thoughtful', emoji: '🤔', label: 'Pensativo', color: 'yellow' },
                        { mood: 'sad', emoji: '😢', label: 'Triste', color: 'blue' },
                        { mood: 'angry', emoji: '😠', label: 'Enojado', color: 'red' }
                      ].map((item) => (
                        <div
                          key={item.mood}
                          className={`flex flex-col items-center gap-2 p-4 rounded-lg border-2 cursor-pointer transition-all ${
                            selectedMood === item.mood
                              ? `border-${item.color}-500 bg-${item.color}-500/10`
                              : 'hover:border-gray-500/50'
                          }`}
                          onClick={() => {
                            setSelectedMood(item.mood)
                            applyToSelected('mood', item.mood)
                          }}
                        >
                          <div className="text-4xl">{item.emoji}</div>
                          <span className="text-sm font-medium">{item.label}</span>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>

                {/* Comida */}
                <Card className="card-hover">
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Utensils className="w-5 h-5 text-green-500" />
                      Lonche
                      {selectedStudents.length > 0 && (
                        <Badge variant="secondary">({selectedStudents.length})</Badge>
                      )}
                    </CardTitle>
                    <CardDescription>
                      ¿Cuánto se comió del lonche?
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="grid grid-cols-3 gap-4">
                      {[
                        { value: 'all', emoji: '🍱', label: 'Todo', color: 'green' },
                        { value: 'half', emoji: '🥙', label: 'Mitad', color: 'yellow' },
                        { value: 'none', emoji: '🥺', label: 'Nada', color: 'red' }
                      ].map((item) => (
                        <div
                          key={item.value}
                          className={`flex flex-col items-center gap-2 p-4 rounded-lg border-2 cursor-pointer transition-all ${
                            selectedLunch === item.value
                              ? `border-${item.color}-500 bg-${item.color}-500/10`
                              : 'hover:border-gray-500/50'
                          }`}
                          onClick={() => {
                            setSelectedLunch(item.value)
                            applyToSelected('lunchIntake', item.value)
                          }}
                        >
                          <div className="text-3xl">{item.emoji}</div>
                          <span className="text-sm font-medium">{item.label}</span>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>

                {/* Acciones rápidas */}
                <Card className="card-hover">
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <CheckCircle2 className="w-5 h-5 text-primary" />
                      Acciones Rápidas
                    </CardTitle>
                    <CardDescription>
                      Aplicar a estudiantes seleccionados
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="flex items-center justify-between p-4 rounded-lg border bg-secondary/50">
                      <div className="flex items-center gap-3">
                        <BedDouble className="w-5 h-5 text-purple-500" />
                        <div>
                          <p className="font-medium">Durmieron la siesta</p>
                          <p className="text-sm text-muted-foreground">
                            Marcar si tomaron la siesta
                          </p>
                        </div>
                      </div>
                      <Button
                        variant={selectedStudents.length > 0 ? "default" : "outline"}
                        disabled={selectedStudents.length === 0}
                        onClick={() => applyToSelected('hadNap', true)}
                        className="neon-accent"
                      >
                        Aplicar
                      </Button>
                    </div>

                    <div className="flex items-center justify-between p-4 rounded-lg border bg-secondary/50">
                      <div className="flex items-center gap-3">
                        <Baby className="w-5 h-5 text-orange-500" />
                        <div>
                          <p className="font-medium">Pañal cambiado</p>
                          <p className="text-sm text-muted-foreground">
                            Marcar si se cambió el pañal
                          </p>
                        </div>
                      </div>
                      <Button
                        variant={selectedStudents.length > 0 ? "default" : "outline"}
                        disabled={selectedStudents.length === 0}
                        onClick={() => applyToSelected('diaperChanged', true)}
                      >
                        Aplicar
                      </Button>
                    </div>

                    <div className="flex items-center justify-between p-4 rounded-lg border bg-secondary/50">
                      <div className="flex items-center gap-3">
                        <Pill className="w-5 h-5 text-red-500" />
                        <div>
                          <p className="font-medium">Medicamento</p>
                          <p className="text-sm text-muted-foreground">
                            Se suministró medicamento
                          </p>
                        </div>
                      </div>
                      <Button
                        variant={selectedStudents.length > 0 ? "default" : "outline"}
                        disabled={selectedStudents.length === 0}
                        onClick={() => applyToSelected('medicationGiven', true)}
                      >
                        Aplicar
                      </Button>
                    </div>
                  </CardContent>
                </Card>

                {/* Logros individuales */}
                <Card className="card-hover">
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Award className="w-5 h-5 text-yellow-500" />
                      Logros del Día
                    </CardTitle>
                    <CardDescription>
                      Agregar logros individuales
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    {selectedStudents.slice(0, 3).map((studentId) => {
                      const student = students.find(s => s.id === studentId)
                      if (!student) return null
                      return (
                        <div key={studentId} className="space-y-2">
                          <div className="flex items-center gap-2">
                            <Avatar className="w-6 h-6">
                              <AvatarFallback className="text-xs">
                                {getInitials(student.name, student.lastName)}
                              </AvatarFallback>
                            </Avatar>
                            <span className="text-sm font-medium">{student.name}</span>
                          </div>
                          <Textarea
                            placeholder="Escribe el logro del día..."
                            value={individualAchievements[studentId] || ''}
                            onChange={(e) =>
                              setIndividualAchievements({
                                ...individualAchievements,
                                [studentId]: e.target.value
                              })
                            }
                            className="min-h-[60px]"
                          />
                        </div>
                      )
                    })}
                    {selectedStudents.length > 3 && (
                      <p className="text-sm text-muted-foreground text-center">
                        +{selectedStudents.length - 3} estudiantes más
                      </p>
                    )}
                  </CardContent>
                </Card>

                {/* Observaciones generales */}
                <Card className="card-hover">
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Award className="w-5 h-5 text-blue-500" />
                      Observaciones Generales
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <Textarea
                      placeholder="Agrega observaciones generales del día..."
                      value={generalNotes}
                      onChange={(e) => setGeneralNotes(e.target.value)}
                      className="min-h-[100px]"
                    />
                  </CardContent>
                </Card>
              </div>
            </div>
          </TabsContent>

          {/* Tab 2: Enviar Reportes */}
          <TabsContent value="send" className="space-y-6">
            <div className="grid lg:grid-cols-2 gap-6">
              {/* Resumen del día */}
              <Card className="card-hover neon-border">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Send className="w-5 h-5 text-primary" />
                    Resumen del Día
                  </CardTitle>
                  <CardDescription>Estado de los reportes de hoy</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex items-center justify-between p-4 rounded-lg border bg-secondary/50">
                    <div className="flex items-center gap-3">
                      <CheckCircle2 className="w-5 h-5 text-green-500" />
                      <div>
                        <p className="font-medium">Completos</p>
                        <p className="text-sm text-muted-foreground">Listos para enviar</p>
                      </div>
                    </div>
                    <Badge className="bg-green-500/20 text-green-500">12</Badge>
                  </div>

                  <div className="flex items-center justify-between p-4 rounded-lg border bg-secondary/50">
                    <div className="flex items-center gap-3">
                      <Award className="w-5 h-5 text-yellow-500" />
                      <div>
                        <p className="font-medium">Incompletos</p>
                        <p className="text-sm text-muted-foreground">Faltan datos</p>
                      </div>
                    </div>
                    <Badge className="bg-yellow-500/20 text-yellow-500">5</Badge>
                  </div>

                  <div className="flex items-center justify-between p-4 rounded-lg border bg-secondary/50">
                    <div className="flex items-center gap-3">
                      <Award className="w-5 h-5 text-red-500" />
                      <div>
                        <p className="font-medium">Sin iniciar</p>
                        <p className="text-sm text-muted-foreground">No capturados</p>
                      </div>
                    </div>
                    <Badge className="bg-red-500/20 text-red-500">3</Badge>
                  </div>
                </CardContent>
              </Card>

              {/* Opciones de envío */}
              <Card className="card-hover">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Mail className="w-5 h-5 text-accent" />
                    Método de Envío
                  </CardTitle>
                  <CardDescription>
                    Selecciona cómo enviar los reportes
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex items-center justify-between p-4 rounded-lg border bg-secondary/50">
                    <div className="flex items-center gap-3">
                      <Mail className="w-5 h-5 text-blue-500" />
                      <div>
                        <p className="font-medium">Correo Electrónico</p>
                        <p className="text-sm text-muted-foreground">
                          Enviar a los padres por email
                        </p>
                      </div>
                    </div>
                    <Switch defaultChecked />
                  </div>

                  <div className="flex items-center justify-between p-4 rounded-lg border bg-secondary/50">
                    <div className="flex items-center gap-3">
                      <MessageSquare className="w-5 h-5 text-green-500" />
                      <div>
                        <p className="font-medium">WhatsApp</p>
                        <p className="text-sm text-muted-foreground">
                          Enviar por WhatsApp Business
                        </p>
                      </div>
                    </div>
                    <Switch />
                  </div>

                  <div className="p-4 rounded-lg border bg-accent/5">
                    <p className="text-sm text-muted-foreground">
                      <strong>Nota:</strong> Para usar WhatsApp se requiere
                      WhatsApp Business API.
                    </p>
                  </div>
                </CardContent>
              </Card>

              {/* Lista de estudiantes para enviar */}
              <Card className="lg:col-span-2 card-hover">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <CheckCircle2 className="w-5 h-5 text-green-500" />
                    Reportes Completos
                  </CardTitle>
                  <CardDescription>
                    Selecciona los reportes a enviar
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <ScrollArea className="h-[400px]">
                    <div className="space-y-3">
                      {filteredStudents.slice(0, 10).map((student, index) => (
                        <div
                          key={student.id}
                          className="flex items-center gap-4 p-4 rounded-lg border bg-secondary/50"
                        >
                          <Checkbox />
                          <Avatar>
                            <AvatarFallback className="bg-accent text-accent-foreground">
                              {getInitials(student.name, student.lastName)}
                            </AvatarFallback>
                          </Avatar>
                          <div className="flex-1">
                            <h3 className="font-semibold">
                              {student.name} {student.lastName}
                            </h3>
                            <p className="text-sm text-muted-foreground">
                              {index < 5
                                ? '✅ Completo'
                                : index < 8
                                ? '⚠️ Incompleto'
                                : '❌ Sin iniciar'}
                            </p>
                          </div>
                          <div className="flex items-center gap-2">
                            <Mail className="w-4 h-4 text-muted-foreground" />
                            <MessageSquare className="w-4 h-4 text-muted-foreground" />
                          </div>
                        </div>
                      ))}
                    </div>
                  </ScrollArea>
                </CardContent>
              </Card>

              {/* Botón de envío */}
              <Card className="lg:col-span-2 neon-border">
                <CardContent className="p-6">
                  <div className="flex items-center justify-between gap-4">
                    <div>
                      <h3 className="font-semibold">Enviar Reportes del Día</h3>
                      <p className="text-sm text-muted-foreground">
                        Se enviarán 12 reportes por correo electrónico
                      </p>
                    </div>
                    <div className="flex items-center gap-2">
                      <Button variant="outline">
                        <Download className="w-4 h-4 mr-2" />
                        Descargar PDF
                      </Button>
                      <Button className="neon-accent">
                        <Send className="w-4 h-4 mr-2" />
                        Enviar Reportes
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Tab 3: Historial */}
          <TabsContent value="history" className="space-y-6">
            <Card className="card-hover">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <History className="w-5 h-5 text-primary" />
                  Historial de Reportes
                </CardTitle>
                <CardDescription>
                  Historial de reportes de estudiantes
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="text-center py-12">
                  <History className="w-16 h-16 mx-auto text-muted-foreground mb-4" />
                  <p className="text-lg font-semibold mb-2">
                    Historial en desarrollo
                  </p>
                  <p className="text-muted-foreground">
                    Próximamente podrás ver el historial completo y generar resúmenes
                    semanales con IA
                  </p>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}
