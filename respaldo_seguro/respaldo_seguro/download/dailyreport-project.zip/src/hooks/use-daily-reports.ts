import { useState, useEffect } from 'react'

export interface DailyReport {
  id: string
  studentId: string
  student?: {
    id: string
    name: string
    lastName: string
  }
  date: Date
  mood: string
  lunchIntake: string
  hadNap: boolean
  usedBathroom: boolean
  diaperChanged: boolean
  diaperNotes: string | null
  medicationGiven: boolean
  medicationName: string | null
  medicationNotes: string | null
  dailyAchievements: string | null
  generalNotes: string | null
  isComplete: boolean
  sentViaEmail: boolean
  sentViaWhatsApp: boolean
  sentAt: Date | null
  createdAt: Date
  updatedAt: Date
}

export function useDailyReports(date?: string, studentId?: string) {
  const [reports, setReports] = useState<DailyReport[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    fetchReports()
  }, [date, studentId])

  async function fetchReports() {
    try {
      setLoading(true)
      const params = new URLSearchParams()
      if (date) params.append('date', date)
      if (studentId) params.append('studentId', studentId)

      const response = await fetch(`/api/daily-reports?${params}`)
      if (!response.ok) throw new Error('Error fetching reports')
      const data = await response.json()
      setReports(data)
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Unknown error')
    } finally {
      setLoading(false)
    }
  }

  async function createReport(data: Partial<DailyReport>) {
    try {
      const response = await fetch('/api/daily-reports', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data)
      })
      if (!response.ok) throw new Error('Error creating report')
      const newReport = await response.json()
      setReports(prev => [newReport, ...prev])
      return newReport
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Unknown error')
      throw err
    }
  }

  async function updateReport(id: string, data: Partial<DailyReport>) {
    try {
      const response = await fetch(`/api/daily-reports/${id}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data)
      })
      if (!response.ok) throw new Error('Error updating report')
      const updatedReport = await response.json()
      setReports(prev => prev.map(r => r.id === id ? updatedReport : r))
      return updatedReport
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Unknown error')
      throw err
    }
  }

  return { reports, loading, error, createReport, updateReport, refetch: fetchReports }
}
